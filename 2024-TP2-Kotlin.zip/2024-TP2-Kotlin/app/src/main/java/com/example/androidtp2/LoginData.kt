package com.example.androidtp2

import javax.security.auth.callback.PasswordCallback

data class LoginData(
    val mail: String,
    val password: String
)
