package com.example.androidtp2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val buttonRegister = findViewById<Button>(R.id.btnRegister)
        buttonRegister.setOnClickListener{
            register()
        }
    }

    private fun register(){
        val nom = findViewById<EditText>(R.id.txtRegisterName).text.toString()
        val mail = findViewById<EditText>(R.id.txtRegisterMail).text.toString()
        val motPasse = findViewById<EditText>(R.id.txtRegisterPassword).text.toString()
        val registerData = RegisterData(nom, mail, motPasse)

        Api().post("https://mypizza.lesmoulinsdudev.com/register", registerData, ::registerSuccess)
    }

    public fun registerSuccess(responseCode: Int){
        if (responseCode == 200) {
            finish()
        }
    }

    public fun goToLogin(view: View)
    {
        finish();
    }
}