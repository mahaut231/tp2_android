package com.example.androidtp2

import android.content.Intent
import android.media.session.MediaSession
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val connexionButton = findViewById<Button>(R.id.btnConect)
        connexionButton.setOnClickListener {
            login()
        }

    }

    public fun registerNewAccount(view: View)
    {
        val intent = Intent(this, RegisterActivity::class.java);
        startActivity(intent);
    }

    public fun loginSuccess(responseCode:Int, token:String? ){
        val intent = Intent(this, OrderActivity::class.java)
        if (responseCode == 200 && token != null){
            startActivity(intent)
        }
    }

    private fun login(){

        val mail = findViewById<EditText>(R.id.txtMail).text.toString()
        val motPasse = findViewById<EditText>(R.id.txtPassword).text.toString()
        val loginData = LoginData(mail, motPasse)

        Api().post("https://mypizza.lesmoulinsdudev.com/auth", loginData, ::loginSuccess )

    }

}